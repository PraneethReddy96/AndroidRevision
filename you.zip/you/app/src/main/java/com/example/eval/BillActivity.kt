package com.example.eval

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import kotlinx.android.synthetic.main.activity_bill.*
import kotlinx.android.synthetic.main.fragment_apple.*
import kotlinx.android.synthetic.main.fragment_banana.*

class BillActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_bill)
        



        var data = intent.getStringExtra("banana")
        var data2 = intent.getStringExtra("apple")

        totalFullBananasTv.setText("Total Orange Price: "+data.toString())
        totalFullApplesTv.setText("Total Apple Price: "+data2.toString())

        var answer = data.toString().toInt() + data2.toString().toInt()

        totalTv.setText("Total: "+answer.toString())


        editApplesBtn.setOnClickListener(View.OnClickListener { 
            
            val intent = Intent(this,AppleActivity::class.java)
            startActivity(intent)
            
        })

        editBananasBtn.setOnClickListener(View.OnClickListener {

            val intent = Intent(this,BananaActivity::class.java)
            startActivity(intent)

        })


        
    }
}