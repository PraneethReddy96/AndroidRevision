package com.example.eval

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class BananaActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_banana)


        var data = intent.getStringExtra("apple")


        val b = Bundle()
        b.putString("message", data)



        val bananaFragment = BananaFragment()
        bananaFragment.setArguments(b)
        supportFragmentManager.beginTransaction().add(R.id.bananContainer,bananaFragment,"banana")
            .addToBackStack("banana")
           .commit()







    }
}