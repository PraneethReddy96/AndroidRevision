package com.example.eval

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class AppleActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val appleFragment = AppleFragment()
        supportFragmentManager.beginTransaction().add(R.id.appleConatiner,appleFragment,"apple")
            .addToBackStack("apple")
            .commit()



    }
}